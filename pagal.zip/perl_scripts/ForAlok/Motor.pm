package Motor;
use MyUtils;
use PDB;
use Atom;
use Residue;
require Exporter;
@ISA = qw(Exporter );
#@EXPORT = qw($fields);

use strict ;
use Carp ;
use FileHandle ;
use Getopt::Long;
use vars qw($AUTOLOAD);
use Getopt::Long;
use Cwd ;
use File::Basename;

my $VERBOSE = 0 ;

my $fields = {
    KVAL => undef, 
    XVAL => undef ,
    LENGTH => undef ,
    ISATTACHED => undef ,
    INITVEL => undef ,
    VEL => undef ,
    W => undef ,
    STALLFORCE => undef ,
};


sub new{
    my $that = shift ; 
	my ($kval,$xval,$length,$isattached,$initvel,$stallforce,$W) = @_ ;
    my $class = ref($that) || $that ;

    my $self =  {}; 
    map { $self->{$_} = undef ; } (keys %{$fields});
    $self->{KVAL} = $kval ; 
	$self->{XVAL} = $xval ;
	$self->{LENGTH} = $length ;
	$self->{ISATTACHED} = $isattached ;
	$self->{INITVEL} = $initvel ;
	$self->{STALLFORCE} = $stallforce ;
	$self->{W} = $W ;
	$self->{VEL} = 0 ;


    bless $self, $class ; 
    $self ;
}

sub AUTOLOAD {
    my $self = shift;
    my $attr = $AUTOLOAD;
    $attr =~ s/.*:://;
    return unless $attr =~ /[^A-Z]/;  # skip DESTROY and all-cap methods
    croak "invalid attribute method: ->$attr()" unless exists $fields->{$attr} ; 
    $self->{$attr} = shift if @_;
    return $self->{$attr};
}

sub SetAttached{
    my $self = shift ;
	$self->{ISATTACHED} = 1 ;
}

sub Detach{
    my $self = shift ;
	$self->{ISATTACHED} = 0 ;
}
sub Attach{
    my $self = shift ;
	$self->{ISATTACHED} = 1 ;
}


sub GetAttached{
    my $self = shift ;
	return $self->{ISATTACHED} ;
}

sub GetVel{
    my $self = shift ;
	return $self->{VEL} ;
}

sub SetXCoord{
    my $self = shift ;
	my ($x) = @_ ;
	$self->{XVAL} =  $self->{XVAL}  + $x ; 
 	
}

sub SetVel{
    my $self = shift ;
	my ($x) = @_ ;
	$self->{VEL} = $x ;
}

sub ComputeNewVelocity{
    my $self = shift ;
	my ($force) = @_ ;
	my $newvel =  ($self->{INITVEL})*(1 - $force/$self->{STALLFORCE});
	$self->{VEL} = $newvel;
	return $newvel ;
	## POW - todo 
}

sub PrintState{
    my $self = shift ;
	print "Motor values : Xval = $self->{XVAL}, velocity = $self->{VEL} \n";

}
