package Cargo;
use MyUtils;
use PDB;
use Atom;
use Residue;
use Motor;
require Exporter;
@ISA = qw(Exporter );
#@EXPORT = qw($fields);

use strict ;
use Carp ;
use FileHandle ;
use Getopt::Long;
use vars qw($AUTOLOAD);
use Getopt::Long;
use Cwd ;
use File::Basename;

my $VERBOSE = 0 ;

my $fields = {
    OPTRAPKVAL => undef, 
    MOTORS => undef ,
    XVAL => undef ,
    TIMESTEP => undef ,
};


sub new{
    my $that = shift ; 
	my ($optrapkval) = @_ ;
    my $class = ref($that) || $that ;

    my $self =  {}; 
    map { $self->{$_} = undef ; } (keys %{$fields});
    $self->{OPTRAPKVAL} = $optrapkval ; 
	$self->{MOTORS} = [];
	$self->{XVAL} = 0 ;
	$self->{TIMESTEP} = 0 ;


    bless $self, $class ; 
    $self ;
}

sub AUTOLOAD {
    my $self = shift;
    my $attr = $AUTOLOAD;
    $attr =~ s/.*:://;
    return unless $attr =~ /[^A-Z]/;  # skip DESTROY and all-cap methods
    croak "invalid attribute method: ->$attr()" unless exists $fields->{$attr} ; 
    $self->{$attr} = shift if @_;
    return $self->{$attr};
}

sub IncrTimpeStep{
    my $self = shift ;
	$self->{TIMESTEP} = $self->{TIMESTEP} + 1;

}

sub GetTimeStep{
    my $self = shift ;
	return $self->{TIMESTEP} ;
}

sub AddMotor{
    my $self = shift ;
    my ($motor) = @_ ; 
	push @{$self->{MOTORS}},$motor ; 

}

sub SetXCoord{
    my $self = shift ;
	my ($x) = @_ ;
	$self->{XVAL} =  $self->{XVAL}  + $x ; 
 	
}

sub ComputeForce{
    my $self = shift ;
    my $force = $self->{OPTRAPKVAL} * $self->{XVAL} ;
    return $force ;
 	
}

sub PrintState{
    my $self = shift ;
	print "Timestep is $self->{TIMESTEP} \n";
	print "Xval of cargo is $self->{XVAL} \n";
	foreach my $motor (@{$self->{MOTORS}}){
		$motor->PrintState();
	}
}

sub FindNumofAttached{
    my $self = shift ;
    my $N = 0 ;
	foreach my $motor (@{$self->{MOTORS}}){
		if($motor->GetAttached() eq 1){
			$N++;
		}
	}
	return $N ; 
}
