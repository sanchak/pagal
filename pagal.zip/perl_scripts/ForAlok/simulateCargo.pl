#!/usr/bin/perl -w 
use strict ;
use FileHandle ;
use Getopt::Long;
use Cwd ;
use MyUtils;
use MyGeom;
use PDB;
use ConfigPDB;
use Math::Geometry ;
use Cargo;
use Motor;


use Time::HiRes qw( usleep ualarm gettimeofday tv_interval clock_gettime clock_getres  clock);
use POSIX qw(floor);
my $commandline = util_get_cmdline("",\@ARGV) ;
my ($infile,$outfile,$which_tech,$listfile,$protein);
my (@expressions);
my $howmany = 100000 ;
my $verbose = 1 ;
GetOptions(
            "which_tech=s"=>\$which_tech ,
            "protein=s"=>\$protein ,
            "infile=s"=>\$infile ,
            "listfile=s"=>\$listfile ,
            "outfile=s"=>\$outfile ,
            "expr=s"=>\@expressions,
            "howmany=i"=>\$howmany ,
           );
die "Dont recognize command line arg @ARGV " if(@ARGV);
my $PWD = cwd;

my $OPTRAPKVAL = 0.1 ;
my $LENGTHofMotor = 60 ; ## in nm 

my $cargo = new Cargo(0.1);

## Add motors
my @motors ;
my $InitialSpeedofMOtor = 1.6 ; ## nm / ms 
my $stallforce = 1.25 ; ## pN
my $W = 1 ;
my $KvalofMotors = 0.09 ;



### Initialize system
my $numofMotors = 10 ;
my $seperation = 16 ;

foreach my $i (1..$numofMotors){
	my $xdist = $i * $seperation ;
	my $motor = new Motor($KvalofMotors,$xdist,$LENGTHofMotor,1,$InitialSpeedofMOtor,$stallforce,$W);
	push @motors, $motor ;

    $cargo->AddMotor($motor);
}

### simulation


my $timestep = 1;


my $isAlwaysAttached = 1 ;


## just to enter while loop once
my $velofmotors = 100 ;

$cargo->PrintState();

my $finalforce = 0 ;
while($velofmotors > 0.02){
	
	$cargo->IncrTimpeStep();

    my $cargomoved = 0 ;
    foreach my $i (0..$numofMotors -1){
	    my $motor = $motors[$i];
	    my $vel = $motor->GetVel();

	    $motor->SetVel($vel);
	    my $displacement = $vel * $timestep ;
	    $motor->SetXCoord($displacement);

		## to move cargo just once, and not for every motor
	    if($isAlwaysAttached && !$cargomoved){
            $cargo->SetXCoord($displacement);
		    $cargomoved = 1 ;
	    }
    }
    
    ## compute trap force
    
    my $forceoncargo = $cargo->ComputeForce();
	$finalforce = $forceoncargo ;
    
    ## distribute force among motors
    if($isAlwaysAttached){
	    my $forcepermotor = $forceoncargo/$numofMotors;
        foreach my $i (0..$numofMotors-1){
	        my $motor = $motors[$i];
	        my $newvel = $motor->ComputeNewVelocity($forcepermotor);
			$velofmotors = $newvel ;
	    }
    }

	# Now decide to detach
	
}


my $probabilityofDetachment = 100 ;
while(1){
	$cargo->IncrTimpeStep();

	my $cntattach = 0 ;
	my $cntdetach = 0 ;
    foreach my $i (0..$numofMotors-1){
	     my $motor = $motors[$i];
         my $r = floor(100*rand());
	     if($r < 1){
		     print "attaching number $i \n";
			 $cntattach++;
	         my $motor = $motors[$i];
		     $motor->Attach();
		 }
	 }

    foreach my $i (0..$numofMotors-1){
	     my $motor = $motors[$i];
         my $r = floor(($probabilityofDetachment)*rand());
	     if($r < 1){
		     print "Detatching number $i \n";
			 $cntdetach++;
	         my $motor = $motors[$i];
		     $motor->Detach();
		 }
	 }
	 print "probabilityofDetachment = $probabilityofDetachment, finalforce = $finalforce number detatched = $cntdetach, attached = $cntattach  \n";
	 my $numofMotorsattached = $cargo->FindNumofAttached();
	 last if(!$numofMotorsattached);
	 print "Number of motors attached = $numofMotorsattached \n";
	 my $forcepermotor = $finalforce/$numofMotorsattached;
	 $probabilityofDetachment = CalibrateProbabiltyOfDetachment($forcepermotor);

}

$cargo->PrintState();

sub CalibrateProbabiltyOfDetachment{
	my ($force) = @_ ;
	my $init = 100 ; 
	return ($init/$force) ;
}



chmod 0777, $outfile ;

sub usage{
    my ($msg) = @_ ;
    print $msg , "\n" ; 
print << "ENDOFUSAGE" ; 
ENDOFUSAGE
    die ;
}
