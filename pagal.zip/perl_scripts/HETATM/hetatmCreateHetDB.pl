#!/usr/bin/perl -w 
use strict ;
use FileHandle ;
use Getopt::Long;
use Cwd ;
use MyUtils;
use MyGeom;
use PDB;
use ConfigPDB;
use Math::Geometry ;
use Math::Geometry::Planar;


use Time::HiRes qw( usleep ualarm gettimeofday tv_interval clock_gettime clock_getres  clock);
use POSIX qw(floor);
my $commandline = util_get_cmdline("",\@ARGV) ;
my ($het2pdb,$pdbseqres,$infile,$outfile,$which_tech,$listfile,$protein);
my (@expressions);
my $howmany = 100000 ;
my $verbose = 0 ;
GetOptions(
            "het2pdb=s"=>\$het2pdb ,
            "pdbseqres=s"=>\$pdbseqres ,
            "protein=s"=>\$protein ,
            "infile=s"=>\$infile ,
            "listfile=s"=>\$listfile ,
            "outfile=s"=>\$outfile ,
            "expr=s"=>\@expressions,
            "howmany=i"=>\$howmany ,
           );
die "Dont recognize command line arg @ARGV " if(@ARGV);
usage( "Need to give a output file name => option -outfile ") if(!defined $outfile);
print "Writing to $outfile - the commands to convert premon.in's\n";
my $ofh = util_write($outfile);

usage( "Need to give a input file name => option -het2pdb ") if(!defined $het2pdb);

#usage( "Need to give a input file name => option -pdbseqres ") if(!defined $pdbseqres);
#print "READING $pdbseqres\n";
#my ($info,$infoSeq2PDB,$mapChainedName2Name) = util_parsePDBSEQRES($pdbseqres,0);

my ($RESULTDIR,$PDBDIR,$FASTADIR,$APBSDIR,$FPOCKET,$SRC,$MATCH3D,$ANNDIR, $UNIPROT) = util_SetEnvVars();
my $PWD = cwd;



print "READING $het2pdb\n";
my ($NOHET,$YESHET,$HET2PDB,$HET2PDBSIZE) = util_parseHETPDB($het2pdb);


my $HETDIR = "HETDIR" ;
print $ofh "mkdir -p $HETDIR\n";

my $Nnotfound = 0 ;
my $Nfound = 0 ;
my $done = {};
foreach my $hetatm (keys %{$HET2PDB}){
	my $N = $HET2PDBSIZE->{$hetatm} ; 

	next if($hetatm ne "SVR");


    my $hetdir = "$HETDIR/$hetatm";
    print $ofh "mkdir -p $hetdir\n" ;

    print $ofh "echo $N > ! $hetdir/size \n";


	my @list = @{$HET2PDB->{$hetatm}};
	my $lstr = join " ", @list ;
    print $ofh "echo $hetatm> ! $hetdir/name\n";
    print $ofh "echo $lstr > ! $hetdir/list.all\n";
    print $ofh "cd $hetdir \n";
    print $ofh "$SRC/HETATM/hetatmCreateHetDBSingle.csh \n";
    print $ofh "cd - \n";

	
}

sub usage{
    my ($msg) = @_ ;
    print $msg , "\n" ; 
print << "ENDOFUSAGE" ; 
ENDOFUSAGE
    die ;
}
