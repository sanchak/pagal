#!/bin/tcsh

pdflatex document.tex 
acr document.pdf & 

