#!/usr/bin/perl -w 
use strict ;
use FileHandle ;
use Getopt::Long;
use Cwd ;
use MyUtils;
use ConfigPDB;
use MyGeom;

use POSIX qw(floor);
my $commandline = util_get_cmdline("",\@ARGV) ;
my ($second,$reverse,$infile,$outfile,$which_tech,$listfile);
my (@expressions);
my $idx = 0;
my $maxlen = 30;
my $minlen = 12;
my $hydro = 8;
my $posratio ;
my $negratio ;
GetOptions(
            "which_tech=s"=>\$which_tech ,
            "infile=s"=>\$infile ,
            "reverse"=>\$reverse ,
            "listfile=s"=>\$listfile ,
            "outfile=s"=>\$outfile ,
            "expr=s"=>\@expressions,
            "idx=i"=>\$idx ,
            "hydro=i"=>\$hydro ,
            "maxlen=i"=>\$maxlen ,
            "second"=>\$second ,
            "minlen=i"=>\$minlen ,
            "posratio=f"=>\$posratio ,
            "negratio=f"=>\$negratio ,
           );
die "Dont recognize command line arg @ARGV " if(@ARGV);
usage( "Need to give a output file name => option -outfile ") if(!defined $outfile);
usage( "Need to give a input file name => option -infile ") if(!defined $infile);
my $ifh = util_read($infile);
my $ofh = util_write($outfile);
my $CNT = 0 ; 
my ($RESULTDIR,$PDBDIR,$FASTADIR) = util_SetEnvVars();


my $startidx = 0 ;
$startidx = 4 if(defined $second);

my $done = {};
while(<$ifh>){
     next if(/^\s*$/);
	 my (@l) = split ;
	 my $nm = $l[$startidx+ 0];
	 my $l = $l[$startidx+ 1];
	 my $h= $l[$startidx+ 2];
	 my $ratio = $l[$startidx+ 3];

	 next if(exists $done->{$nm});
	 $done->{$nm} = 1 ;
	 next if($h< $hydro);
	 next if($l > $maxlen);
	 next if($l < $minlen);
	 next if(defined $posratio && $ratio < $posratio);
	 next if(defined $negratio && $ratio > $negratio);

	 print $ofh $_ ;
}
close($ifh);


print STDERR "Output written in $outfile\n";

chmod 0777, $outfile ;
sub usage{
    my ($msg) = @_ ;
    print $msg , "\n" ; 
print << "ENDOFUSAGE" ; 
ENDOFUSAGE
    die ;
}
