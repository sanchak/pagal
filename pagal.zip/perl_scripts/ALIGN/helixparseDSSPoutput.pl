#!/usr/bin/perl -w 
use strict ;
use FileHandle ;
use Getopt::Long;
use Cwd ;
use MyUtils;
use MyGeom;
use PDB;
use ConfigPDB;
use Math::Geometry ;
use Math::Geometry::Planar;


use Time::HiRes qw( usleep ualarm gettimeofday tv_interval clock_gettime clock_getres  clock);
use POSIX qw(floor);
my $commandline = util_get_cmdline("",\@ARGV) ;
my ($infile,$outfile,$which_tech,$listfile,$protein);
my (@expressions);
my $howmany = 100000 ;
my $verbose = 1 ;
GetOptions(
            "which_tech=s"=>\$which_tech ,
            "protein=s"=>\$protein ,
            "infile=s"=>\$infile ,
            "listfile=s"=>\$listfile ,
            "outfile=s"=>\$outfile ,
            "expr=s"=>\@expressions,
            "howmany=i"=>\$howmany ,
           );
die "Dont recognize command line arg @ARGV " if(@ARGV);
usage( "Need to give a output file name => option -outfile ") if(!defined $outfile);
my $ofh = util_write($outfile);
usage( "Need to give a input file name => option -infile ") if(!defined $infile);
my $ifh = util_read($infile);
usage( "Need to give a protein pdb id -option -protein  ") if(!defined $protein);
my $CNT = 0 ; 
#my ($RESULTDIR,$PDBDIR,$FASTADIR,$APBSDIR,$FPOCKET,$SRC) = util_SetEnvVars();
my ($RESULTDIR,$PDBDIR,$FASTADIR,$APBSDIR,$FPOCKET,$SRC,$MATCH3D,$ANNDIR, $UNIPROT) = util_SetEnvVars();
my $PWD = cwd;

my $pdb = "$PDBDIR/$protein.pdb";
my $pdb1 = new PDB();
$pdb1->ReadPDB($pdb);

my $ofhhth = util_append("HTH");

while(<$ifh>){
     last if(/#  RESIDUE AA STRUCTURE BP1 BP2/);
}

my @arr = ();
foreach my $i (0...10000){
	push @arr, 0 ;
}

my $final = 0 ;
while(<$ifh>){
	next if(/^\s*$/);
     chop ;
	 my (@l) = split ; 
	 my $n = $l[1];
	 $final= $n;
	 my $h = $l[4];
	 if($h eq "H" || $h eq "G" || $h eq "I"){
	 	$arr[$n] = 1 ;
	 }
}
$final++;
print "Setting 2 value to $final\n";
$arr[$final]= 2;

my $idx = 0 ;
my $prevend = 0 ;
my $prevstart = 0 ;
my $start = 0 ;
my $helixnumber = 0 ;
while($idx < 10000){
   ($idx,$start) = GetNextStretch(\@arr,$idx,$helixnumber);
   last if($idx eq -1);
   my $diff = $start - $prevend ;
   if($diff < 5 && $helixnumber){
   	   my $prevhnumber = $helixnumber -1 ;
	   my $QQQ = "$protein.helix$prevhnumber";
	   my $PPP = "$protein.helix$helixnumber";
       print $ofhhth "$QQQ $PPP $protein $diff $prevstart $idx   \n";
   }

   $prevend = $idx; 
   $prevstart = $start; 
   $idx++;
   $helixnumber++;

}


sub GetNextStretch{
	my ($l,$idx,$hnumber) = @_;
	my @l = @{$l};
	my @ret ; 
	my $start;
	my $end;
	foreach my $i ($idx...10000){
		my $x = $l[$i];
	    return -1 if($x eq 2);
		if($x eq 1){
			$start = $i;
			last ;
		}
	}
	return -1 if(!defined $start) ;

	foreach my $i ($start...10000){
		my $x = $l[$i];
		if($x eq 0 || $x eq 2){
			$end = $i -1 ;
			last ;
		}
	}
	die "start = $start " if(!defined $end);
		my $tableofres = {};
		foreach my $i ($start..$end){
			$tableofres->{$i} = 1 ;
		}
	    my $PPP = "$protein.helix$hnumber";
	    my $OOO = "$PPP.pdb";
		#print $ofhAllNames "$PPP\n";
        my $ofhhelix= util_write($OOO);
		print "Writing hnumber $hnumber to file $OOO : residues $start to $end \n";
		$pdb1->ReadPDBAndWriteSubset($pdb,$tableofres,$ofhhelix);
		close($ofhhelix);
	print "$idx $start $end \n";
	return ($end,$start) ;
}

close($ifh);

sub usage{
    my ($msg) = @_ ;
    print $msg , "\n" ; 
print << "ENDOFUSAGE" ; 
ENDOFUSAGE
    die ;
}
