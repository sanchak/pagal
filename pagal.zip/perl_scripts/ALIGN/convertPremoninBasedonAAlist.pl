#!/usr/bin/perl -w 
use strict ;
use FileHandle ;
use Getopt::Long;
use Cwd ;
use MyUtils;
  use Time::HiRes qw( usleep ualarm gettimeofday tv_interval
   clock_gettime clock_getres  clock
   );

use PDB;
use Atom;
use Residue;
use ConfigPDB;


use POSIX qw(floor);
use Math::Combinatorics;
my $commandline = util_get_cmdline("",\@ARGV) ;
my ($pdb1,$pdb2,$infile,$outfile,$atomidx,$dontrunpymol);
my ($anndir,$listfile,$annotate,$anndir1,$anndir2,$aalist,$dist,$size,$findresidues,$maxresults,$inconf,$outconf,$resultfile,$checkself);
my ($grpconfig) = $ENV{CONFIGGRP} or die ;
my $MINDIST = 2 ;
$, = "  ";
my $LEN = 10 ; 
my $verbose = 0 ;
GetOptions(
            "pdb1=s"=>\$pdb1 ,
            "anndir1=s"=>\$anndir1 ,
            "anndir2=s"=>\$anndir2 ,
            "listfile=s"=>\$listfile ,
            "checkself"=>\$checkself ,
            "dontrunpymol"=>\$dontrunpymol ,
            "findresidues"=>\$findresidues ,
            "atomidx=s"=>\$atomidx ,
            "resultfile=s"=>\$resultfile ,
            "maxresults=i"=>\$maxresults ,
            "dist=f"=>\$dist ,
            "len=i"=>\$LEN ,
            "size=i"=>\$size ,
            "infile=s"=>\$infile ,
            "aalist=s"=>\$aalist ,
            "grpconfig=s"=>\$grpconfig ,
            "outfile=s"=>\$outfile 
           );
die "Dont recognize command line arg @ARGV " if(@ARGV);
usage( "Need to give a aalist => option -aalist ") if(!defined $aalist);
usage( "Need to give a anndir1 => option -anndir1 ") if(!defined $anndir1);
usage( "Need to give a anndir2 => option -anndir2 ") if(!defined $anndir2);
usage( "Need to give a size => option -size ") if(!defined $size);
usage( "Need to give a listfile => option -listfile ") if(!defined $listfile);
#usage( "Need to give a residue number") if(!defined $atomidx);
my ($RESULTDIR,$PDBDIR,$FASTADIR,$APBSDIR,$FPOCKET,$SRC,$MATCH3D,$ANNDIR, $UNIPROT) = util_SetEnvVars();
my $ofh = util_write($outfile);

ConfigPDB_Init($grpconfig);

my ($aainfo,$grplist) = util_ParseAAGroups($aalist);

my @list= util_read_list_sentences($listfile);

foreach my $i (@list){
   my $infile = "$anndir1/$i.$size.premon.in"; 
   my $ifh = util_read($infile);

   print "iinfile = $infile\n" if($verbose);

   next if(! -e $infile || -z $infile);
   print $ofh "$i\n";
   my $Outfile = "$anndir2/$i.$size.premon.in"; 
   my $OFH = util_write($Outfile);
   while(<$ifh>){
		if(/^\s*STR /){
                my ($junk,$str) = split ;
				print "$str llll\n" if($verbose);
				my @l = split "", $str ;
				my $sets = {};
				foreach my $K (@l){
					$sets->{$K} = [];
				    my $ORIG = $aainfo->{$K} ; 
				    foreach my $grp (keys %{$aainfo}){
					    my $val = $aainfo->{$grp};
						if($val eq $ORIG){
					        print "$grp $val \n" if($verbose);
							push @{$sets->{$K}}, $grp ;
						}
				    }
				}

				my $A = shift @l ;
				my $B = shift @l ;
				my $C = shift @l ;
				my $D = shift @l ;
				#die " $A $B $C $D\n";
				my @A = @{$sets->{$A}};
				foreach my $a (@A){
				     my @B = @{$sets->{$B}};
				     foreach my $b (@B){
				          my @C = @{$sets->{$C}};
				          foreach my $c (@C){
				               my @D = @{$sets->{$D}};
				               foreach my $d (@D){
							   	    print $OFH "STR $a$b$c$d\n"; ;
							   }
						  }
				    }
				}
				die if(@l);


		}
		else{
			print $OFH $_ ; 
		}
  }
  close($ifh);
  close($OFH);
}


sub usage{
    my ($msg) = @_ ;
    print $msg , "\n" ; 
print << "ENDOFUSAGE" ; 
ENDOFUSAGE
    die ;

}
